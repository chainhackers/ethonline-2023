export interface TokensIconsPropsI {
  anchorCurrency: string;
  tokens: string[];
}
