export interface DateCellPropsI {
  cellValue: number;
}
