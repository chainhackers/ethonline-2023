export interface PoolsPagePropsI {
  poolsType: string;
}
